# Guardian

Web protection multi-platform (extension, desktop Windows/Linux, Android) dengan satu UI & satu core TypeScript.

    pnpm install
    pnpm filters        # unduh & bangun filter list
    pnpm test           # unit test core
    pnpm dev:ext        # build extension (watch) -> apps/extension/dist, load unpacked di Chrome

Aturan: `packages/core` tidak boleh import API platform (chrome/tauri/capacitor).
