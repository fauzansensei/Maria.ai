import { writeFileSync, mkdirSync } from "node:fs";
import { parseHosts, type Rule } from "../packages/core/src";
import sources from "./sources.json";

let id = 1;
const all: Rule[] = [];

for (const s of sources) {
  const text = await (await fetch(s.url)).text();
  const rules = parseHosts(text, s.category as Rule["category"], id);
  id += rules.length;
  all.push(...rules);
  console.log(`${s.name}: ${rules.length} rules`);
}

mkdirSync("apps/desktop/src-tauri", { recursive: true });
mkdirSync("apps/extension/public/rules", { recursive: true });

// Desktop & Android (resolver lokal)
writeFileSync("apps/desktop/src-tauri/rules.json", JSON.stringify(all));

// Extension MV3 (dibatasi kuota static rules)
const dnr = all.slice(0, 30000).map((r) => ({
  id: r.id,
  priority: 1,
  action: { type: "block" },
  condition: {
    urlFilter: `||${r.domain}^`,
    resourceTypes: ["script", "xmlhttprequest", "sub_frame", "image"],
  },
}));
writeFileSync("apps/extension/public/rules/core.json", JSON.stringify(dnr));
