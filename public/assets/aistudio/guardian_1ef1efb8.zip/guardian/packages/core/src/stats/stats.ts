import type { BlockEvent, Stats } from "../types";

export const emptyStats = (): Stats => ({
  total: 0,
  byDay: {},
  byCategory: { ads: 0, tracker: 0, malware: 0, phishing: 0 },
});

export function record(stats: Stats, ev: BlockEvent): Stats {
  const day = new Date(ev.ts).toISOString().slice(0, 10);
  return {
    total: stats.total + 1,
    byDay: { ...stats.byDay, [day]: (stats.byDay[day] ?? 0) + 1 },
    byCategory: { ...stats.byCategory, [ev.category]: stats.byCategory[ev.category] + 1 },
  };
}
