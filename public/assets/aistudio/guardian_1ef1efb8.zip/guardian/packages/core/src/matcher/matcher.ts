import type { Rule } from "../types";

/** Cocokkan hostname beserta semua parent domain-nya. */
export class DomainMatcher {
  private map = new Map<string, Rule>();

  constructor(rules: Rule[]) {
    for (const r of rules) this.map.set(r.domain, r);
  }

  match(hostname: string): Rule | undefined {
    const parts = hostname.toLowerCase().split(".");
    for (let i = 0; i < parts.length - 1; i++) {
      const hit = this.map.get(parts.slice(i).join("."));
      if (hit) return hit;
    }
    return undefined;
  }
}
