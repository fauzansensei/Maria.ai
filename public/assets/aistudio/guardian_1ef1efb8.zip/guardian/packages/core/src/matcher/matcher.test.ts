import { describe, it, expect } from "vitest";
import { DomainMatcher } from "./matcher";
import { parseHosts } from "../filters/hosts";

const hosts = `
# komentar
0.0.0.0 doubleclick.net
0.0.0.0 evil.example.com
127.0.0.1 localhost
`;

describe("DomainMatcher", () => {
  const m = new DomainMatcher(parseHosts(hosts, "ads", 1));

  it("cocokkan domain persis", () => {
    expect(m.match("doubleclick.net")?.domain).toBe("doubleclick.net");
  });
  it("cocokkan subdomain lewat parent", () => {
    expect(m.match("ads.doubleclick.net")?.domain).toBe("doubleclick.net");
  });
  it("tidak memblokir domain bersih", () => {
    expect(m.match("example.com")).toBeUndefined();
  });
  it("localhost diabaikan", () => {
    expect(m.match("localhost")).toBeUndefined();
  });
});
