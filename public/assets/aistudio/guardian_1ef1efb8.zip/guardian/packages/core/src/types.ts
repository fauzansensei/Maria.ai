export type ResourceType = "script" | "image" | "xhr" | "sub_frame" | "main_frame";

export interface Rule {
  id: number;
  domain: string;
  category: "ads" | "tracker" | "malware" | "phishing";
}

export interface BlockEvent {
  ts: number;
  url: string;
  tabDomain: string;
  ruleId: number;
  category: Rule["category"];
}

export interface Stats {
  total: number;
  byDay: Record<string, number>;
  byCategory: Record<Rule["category"], number>;
}
