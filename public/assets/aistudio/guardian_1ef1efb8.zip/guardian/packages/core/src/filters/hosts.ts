import type { Rule } from "../types";

export function parseHosts(text: string, category: Rule["category"], startId: number): Rule[] {
  const seen = new Set<string>();
  const rules: Rule[] = [];
  for (const raw of text.split("\n")) {
    const line = raw.split("#")[0].trim();
    if (!line) continue;
    const [ip, host] = line.split(/\s+/);
    if (!host || !["0.0.0.0", "127.0.0.1"].includes(ip)) continue;
    if (host === "localhost" || seen.has(host)) continue;
    seen.add(host);
    rules.push({ id: startId + rules.length, domain: host, category });
  }
  return rules;
}
