import { registerPlugin } from "@capacitor/core";
import type { PlatformAdapter } from "./types";

interface GuardianPlugin {
  isProtected(o: { domain: string }): Promise<{ value: boolean }>;
  setProtected(o: { domain: string; on: boolean }): Promise<void>;
  getStats(): Promise<any>;
  getEvents(o: { limit: number }): Promise<{ events: any[] }>;
  blockedToday(): Promise<{ value: number }>;
}
const Guardian = registerPlugin<GuardianPlugin>("Guardian");

export const capacitorAdapter: PlatformAdapter = {
  getCurrentDomain: async () => "system-wide",
  isProtected: async (d) => (await Guardian.isProtected({ domain: d })).value,
  setProtected: (domain, on) => Guardian.setProtected({ domain, on }),
  getStats: () => Guardian.getStats(),
  getRecentEvents: async (limit) => (await Guardian.getEvents({ limit })).events,
  blockedOnCurrent: async () => (await Guardian.blockedToday()).value,
};
