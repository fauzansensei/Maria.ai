import { invoke } from "@tauri-apps/api/core";
import type { PlatformAdapter } from "./types";

export const tauriAdapter: PlatformAdapter = {
  getCurrentDomain: async () => "system-wide",
  isProtected: (domain) => invoke("is_protected", { domain }),
  setProtected: (domain, on) => invoke("set_protected", { domain, on }),
  getStats: () => invoke("get_stats"),
  getRecentEvents: (limit) => invoke("get_events", { limit }),
  blockedOnCurrent: () => invoke("blocked_today"),
};
