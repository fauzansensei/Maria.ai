import type { PlatformAdapter } from "./types";
import { emptyStats } from "@guardian/core";

export const extensionAdapter: PlatformAdapter = {
  async getCurrentDomain() {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    return new URL(t.url!).hostname;
  },
  async isProtected(domain) {
    const { sites = {} } = await chrome.storage.local.get("sites");
    return sites[domain] ?? true;
  },
  async setProtected(domain, on) {
    await chrome.runtime.sendMessage({ type: "toggle", domain, on });
  },
  async getStats() {
    const { stats } = await chrome.storage.local.get("stats");
    return stats ?? emptyStats();
  },
  async getRecentEvents(limit) {
    const { events = [] } = await chrome.storage.local.get("events");
    return events.slice(-limit).reverse();
  },
  async blockedOnCurrent() {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    const r = await chrome.declarativeNetRequest.getMatchedRules({ tabId: t.id! });
    return r.rulesMatchedInfo.length;
  },
};
