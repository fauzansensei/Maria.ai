import type { BlockEvent, Stats } from "@guardian/core";

export interface PlatformAdapter {
  getCurrentDomain(): Promise<string>;
  isProtected(domain: string): Promise<boolean>;
  setProtected(domain: string, on: boolean): Promise<void>;
  getStats(): Promise<Stats>;
  getRecentEvents(limit: number): Promise<BlockEvent[]>;
  blockedOnCurrent(): Promise<number>;
}
