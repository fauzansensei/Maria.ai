import { createContext, useContext } from "react";
import type { PlatformAdapter } from "@guardian/platform/types";

const Ctx = createContext<PlatformAdapter | null>(null);
export const AdapterProvider = Ctx.Provider;
export const useAdapter = () => {
  const a = useContext(Ctx);
  if (!a) throw new Error("AdapterProvider missing");
  return a;
};
