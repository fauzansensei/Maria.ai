import { useEffect, useState } from "react";
import { ShieldCheck, ShieldOff } from "lucide-react";
import { useAdapter } from "./AdapterContext";

export function ProtectionToggle() {
  const adapter = useAdapter();
  const [domain, setDomain] = useState("");
  const [on, setOn] = useState(true);

  useEffect(() => {
    (async () => {
      const d = await adapter.getCurrentDomain();
      setDomain(d);
      setOn(await adapter.isProtected(d));
    })();
  }, [adapter]);

  const flip = async () => {
    setOn(!on);
    await adapter.setProtected(domain, !on);
  };

  return (
    <button
      onClick={flip}
      aria-label={`Protection for ${domain}`}
      className={`h-16 w-16 rounded-full grid place-items-center transition ${
        on ? "bg-emerald-500 shadow-lg shadow-emerald-500/30" : "bg-slate-700"
      }`}
    >
      {on ? <ShieldCheck /> : <ShieldOff />}
    </button>
  );
}
