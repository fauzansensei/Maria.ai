import { useEffect, useState } from "react";
import type { Stats } from "@guardian/core";
import { emptyStats } from "@guardian/core";
import { useAdapter } from "./AdapterContext";
import { ProtectionToggle } from "./ProtectionToggle";

export function Dashboard({ compact = false }: { compact?: boolean }) {
  const adapter = useAdapter();
  const [domain, setDomain] = useState("");
  const [blocked, setBlocked] = useState(0);
  const [stats, setStats] = useState<Stats>(emptyStats());

  useEffect(() => {
    (async () => {
      setDomain(await adapter.getCurrentDomain());
      setBlocked(await adapter.blockedOnCurrent());
      setStats(await adapter.getStats());
    })();
  }, [adapter]);

  return (
    <div className={`${compact ? "w-80" : "w-full max-w-md"} mx-auto bg-slate-900 text-slate-100 p-5 rounded-2xl space-y-5 text-center`}>
      <p className="text-xs text-slate-400">{domain}</p>
      <p className="text-4xl font-bold">Blocked: {blocked}</p>
      <p className="text-xs text-slate-500">Total blocked: {stats.total.toLocaleString()}</p>
      <div className="flex justify-center"><ProtectionToggle /></div>
    </div>
  );
}
