# @guardian/android (Capacitor)

    pnpm add @capacitor/core @capacitor/cli @capacitor/android
    npx cap init Guardian id.guardian.app
    npx cap add android

Buat plugin Kotlin "Guardian" (VpnService lokal) dengan method:
isProtected, setProtected, getStats, getEvents, blockedToday.
Entry UI pakai `capacitorAdapter`.
