# @guardian/desktop (Tauri, Windows + Linux)

Inisialisasi di folder ini:

    pnpm create tauri-app . --template react-ts

Lalu di `src/main.tsx` pakai:

    <AdapterProvider value={tauriAdapter}><Dashboard /></AdapterProvider>

Rust (src-tauri): baca `rules.json` (hasil `pnpm filters`), jalankan resolver DNS lokal
(crate `hickory-server`), dan expose command: is_protected, set_protected, get_stats,
get_events, blocked_today.
