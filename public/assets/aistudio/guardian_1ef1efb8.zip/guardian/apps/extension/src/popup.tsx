import { createRoot } from "react-dom/client";
import { AdapterProvider, Dashboard } from "@guardian/ui";
import { extensionAdapter } from "@guardian/platform/extension";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <AdapterProvider value={extensionAdapter}>
    <Dashboard compact />
  </AdapterProvider>
);
