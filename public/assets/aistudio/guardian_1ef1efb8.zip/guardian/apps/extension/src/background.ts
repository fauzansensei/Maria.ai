const ALLOW_BASE = 100000;

const domainId = (d: string) =>
  ALLOW_BASE + [...d].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 800000, 7);

async function setSiteProtection(domain: string, on: boolean) {
  const id = domainId(domain);
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [id],
    addRules: on
      ? []
      : [{
          id,
          priority: 1000,
          action: { type: "allowAllRequests" as chrome.declarativeNetRequest.RuleActionType },
          condition: {
            requestDomains: [domain],
            resourceTypes: ["main_frame", "sub_frame"] as chrome.declarativeNetRequest.ResourceType[],
          },
        }],
  });
  const { sites = {} } = await chrome.storage.local.get("sites");
  sites[domain] = on;
  await chrome.storage.local.set({ sites });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "toggle") setSiteProtection(msg.domain, msg.on);
});
