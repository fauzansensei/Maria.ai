import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore, Timestamp } from "firebase-admin/firestore";
import type { Verdict } from "./types";

// Hapus blok ini kalau Maria sudah init firebase-admin di tempat lain.
if (!getApps().length) {
  initializeApp(
    process.env.FIREBASE_SERVICE_ACCOUNT
      ? { credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) }
      : undefined
  );
}
const db = getFirestore();
const id = (s: string) => encodeURIComponent(s);
const ts = (ms: number) => Timestamp.fromMillis(ms);

export async function blockTemp(source: string, ttlSec: number, reason: string) {
  await db.collection("blocklist").doc(id(source)).set({
    reason, expiresAt: ts(Date.now() + ttlSec * 1000),   // aktifkan TTL policy di field ini
  });
}

export async function blockedFor(source: string): Promise<number> {
  const d = await db.collection("blocklist").doc(id(source)).get();
  if (!d.exists) return 0;
  const left = d.data()!.expiresAt.toMillis() - Date.now();
  return left > 0 ? Math.ceil(left / 1000) : 0;           // detik tersisa
}

export async function logEvent(v: Verdict, action: string, applied: boolean, mode: string, reason?: string) {
  await db.collection("security_events").add({
    ...v, action, applied, mode, reason: reason ?? null,
    at: ts(Date.now()), expiresAt: ts(Date.now() + 7 * 864e5),
  });
}

// Pelanggaran serius berulang dari sumber yang sama dalam 10 menit
export async function recentOffenses(source: string): Promise<number> {
  const snap = await db.collection("security_events")
    .where("source", "==", source).where("at", ">", ts(Date.now() - 600_000)).limit(20).get();
  return snap.docs.filter(d => d.data().confidence >= 0.7).length;
}

// Skor global untuk level DEFCON
export async function recentScore(): Promise<number> {
  const snap = await db.collection("security_events")
    .where("at", ">", ts(Date.now() - 600_000)).limit(200).get();
  return snap.docs.reduce((s, d) => s + d.data().confidence * 3, 0);
}

export async function isKnownBadHash(hash: string): Promise<boolean> {
  return (await db.collection("known_bad_hashes").doc(hash).get()).exists;
}
