// api/chat.ts (contoh pemasangan)
import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuth } from "firebase-admin/auth";
import { guard, sanitizeOutput } from "../defcon/guard";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // 1) Verifikasi login Firebase (opsional tapi disarankan)
  let uid: string | null = null;
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (token) { try { uid = (await getAuth().verifyIdToken(token)).uid; } catch {} }

  // 2) DEFCON paling awal, sebelum memanggil Gemini
  if (!(await guard(req, res, { message: req.body?.message, verifiedUid: uid }))) return;

  // 3) ...panggil Gemini seperti biasa
  const reply: string = "...";

  // 4) Redaksi secret di output
  res.json({ reply: sanitizeOutput(reply) });
}
