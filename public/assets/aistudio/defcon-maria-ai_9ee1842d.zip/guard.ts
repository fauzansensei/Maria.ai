import type { VercelRequest, VercelResponse } from "@vercel/node";
import { detectBadUpload, detectBadUrls, detectFlood, detectPromptInjection, detectXss, redactSecrets, sha256 } from "./detectors";
import { authorize, levelFromScore, pickAction } from "./policy";
import { blockedFor, blockTemp, isKnownBadHash, logEvent, recentOffenses, recentScore } from "./store";
import { getMode, type Verdict } from "./types";

const ALLOW_IPS = new Set((process.env.DEFCON_ALLOW_IPS ?? "").split(",").filter(Boolean));

export const clientIp = (req: VercelRequest) =>
  String(req.headers["x-forwarded-for"] ?? "").split(",")[0].trim() || "unknown";

interface Input {
  message?: string;
  uploads?: { name: string; data: Buffer }[];
  verifiedUid?: string | null;   // hasil verifyIdToken Firebase; null = anonim
}

/** true = lanjut proses. false = guard sudah membalas response. */
export async function guard(req: VercelRequest, res: VercelResponse, input: Input): Promise<boolean> {
  const mode = getMode();
  if (mode === "off") return true;

  const source = clientIp(req);
  const verified = !!input.verifiedUid;
  if (ALLOW_IPS.has(source)) return true;

  if (mode === "enforce") {
    const left = await blockedFor(source);
    if (left > 0) { res.setHeader("Retry-After", left); res.status(429).json({ error: "temp_blocked", retryAfter: left }); return false; }
  }

  const verdicts: Verdict[] = [];
  const push = (v: Verdict | null) => v && verdicts.push(v);
  push(detectFlood(source));
  if (input.message) {
    push(detectPromptInjection(input.message, source));
    push(detectXss(input.message, source));
    push(detectBadUrls(input.message, source));
  }
  for (const f of input.uploads ?? []) {
    push(detectBadUpload(f.name, f.data, source));
    if (await isKnownBadHash(sha256(f.data)))
      push({ kind: "malware_upload", confidence: 0.99, evidence: ["hash-malware-dikenal"], source });
  }

  let reject = false;
  for (const v of verdicts) {
    const action = pickAction(v, await recentOffenses(source), verified);
    const auth = authorize(v, action, source, verified);
    const applied = mode === "enforce" && auth.allowed;
    await logEvent(v, action, applied, mode, auth.allowed ? undefined : auth.reason);
    if (!applied || !auth.allowed) continue;
    if (action === "reject_request") reject = true;
    if (action === "rate_limit" || action === "block_temp") {
      await blockTemp(source, auth.ttlSec!, v.kind);
      reject = true;
    }
  }

  if (reject) {
    res.status(400).json({ error: "request_rejected", message: "Permintaan ditolak oleh DEFCON: terdeteksi pola serangan." });
    return false;
  }
  return true;
}

/** Pakai di output Maria sebelum dikirim ke user. */
export const sanitizeOutput = (text: string) => redactSecrets(text).text;

/** Untuk badge DEFCON di header. */
export const currentLevel = async () => levelFromScore(await recentScore());
