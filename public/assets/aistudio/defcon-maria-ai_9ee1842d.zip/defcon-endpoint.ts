// api/defcon.ts
import type { VercelRequest, VercelResponse } from "@vercel/node";
import { currentLevel } from "../defcon/guard";
import { getMode } from "../defcon/types";

export default async function handler(_: VercelRequest, res: VercelResponse) {
  res.setHeader("Cache-Control", "no-store");
  res.json({ level: await currentLevel(), mode: getMode() });
}
