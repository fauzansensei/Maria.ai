// Sembunyikan jendela konsol di Windows saat release.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    guardian_lib::run()
}
