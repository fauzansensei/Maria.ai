use guardian_core::signatures::EICAR_SHA256;
use guardian_core::*;
use std::fs;
use std::path::PathBuf;
use std::sync::atomic::AtomicBool;

const EICAR: &str = r"X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*";

fn tmp(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("guardian-test-{}-{}", name, new_id()));
    fs::create_dir_all(&d).unwrap();
    d
}

#[test]
fn eicar_constant_matches_real_hash() {
    let d = tmp("hash");
    let f = d.join("e.com");
    fs::write(&f, EICAR).unwrap();
    assert_eq!(sha256_file(&f).unwrap(), EICAR_SHA256);
}

#[test]
fn scan_finds_eicar_and_ignores_clean() {
    let d = tmp("scan");
    fs::write(d.join("clean.txt"), "halo dunia").unwrap();
    fs::write(d.join("virus.bin"), EICAR).unwrap();
    let db = SignatureDb::with_builtin();
    let cancel = AtomicBool::new(false);
    let mut last = Progress::default();
    let sum = scan_paths(&[d.clone()], &db, &ScanOptions::default(), &cancel, &mut |p| last = p.clone());
    assert_eq!(sum.scanned, 2);
    assert_eq!(sum.threats.len(), 1);
    assert_eq!(sum.threats[0].name, "EICAR-Test-File");
    assert_eq!(sum.threats[0].severity, "high");
    assert_eq!(last.total, 2);
}

#[test]
fn exclude_and_cancel_work() {
    let d = tmp("excl");
    let q = d.join("quarantine");
    fs::create_dir_all(&q).unwrap();
    fs::write(q.join("v.qbin"), EICAR).unwrap();
    fs::write(d.join("ok.txt"), "x").unwrap();
    let db = SignatureDb::with_builtin();
    let opts = ScanOptions { exclude: vec![q], ..Default::default() };
    let sum = scan_paths(&[d.clone()], &db, &opts, &AtomicBool::new(false), &mut |_| {});
    assert_eq!(sum.scanned, 1);
    assert!(sum.threats.is_empty());

    let sum = scan_paths(&[d], &db, &ScanOptions::default(), &AtomicBool::new(true), &mut |_| {});
    assert_eq!(sum.scanned, 0);
}

#[test]
fn heuristics_double_extension_and_disguised_exe() {
    let d = tmp("heur");
    fs::write(d.join("laporan.pdf.exe"), "bukan apa-apa").unwrap();
    // PE minimal: "MZ", e_lfanew=0x40 menunjuk "PE\0\0"
    let mut pe = vec![0u8; 0x80];
    pe[0] = b'M';
    pe[1] = b'Z';
    pe[0x3c] = 0x40;
    pe[0x40..0x44].copy_from_slice(b"PE\0\0");
    fs::write(d.join("foto.jpg"), &pe).unwrap();
    fs::write(d.join("catatan.txt"), "MZ ini cuma teks biasa").unwrap();
    let db = SignatureDb::with_builtin();
    let sum = scan_paths(&[d], &db, &ScanOptions::default(), &AtomicBool::new(false), &mut |_| {});
    let mut names: Vec<_> = sum.threats.iter().map(|t| t.name.clone()).collect();
    names.sort();
    assert_eq!(names, vec!["Heuristic.DisguisedExecutable", "Heuristic.DoubleExtension"]);
    assert!(sum.threats.iter().all(|t| t.severity == "medium"));
}

#[test]
fn quarantine_roundtrip_and_delete() {
    let d = tmp("quar");
    let f = d.join("virus.bin");
    fs::write(&f, EICAR).unwrap();
    let db = SignatureDb::with_builtin();
    let th = scan_file(&f, &db, u64::MAX).unwrap().unwrap();

    let q = Quarantine::new(d.join("q")).unwrap();
    let item = q.add(&th).unwrap();
    assert!(!f.exists(), "file asli harus hilang");
    assert_eq!(q.list().len(), 1);
    // isi di karantina tidak boleh sama dengan aslinya
    let stored = fs::read(q.dir().join(format!("{}.qbin", item.id))).unwrap();
    assert_ne!(stored, EICAR.as_bytes());

    let back = q.restore(&item.id).unwrap();
    assert_eq!(fs::read_to_string(back).unwrap(), EICAR);
    assert!(q.list().is_empty());

    let th2 = scan_file(&f, &db, u64::MAX).unwrap().unwrap();
    let item2 = q.add(&th2).unwrap();
    q.delete(&item2.id).unwrap();
    assert!(q.list().is_empty());
    assert!(!f.exists());
}

#[test]
fn signature_text_parsing() {
    let mut db = SignatureDb::default();
    let a = "a".repeat(64);
    let b = "b".repeat(64);
    let c = "c".repeat(64);
    let text = format!(
        "# komentar\n{a}\n{b},Evil.Thing,Trojan\n\"2025-01-01 10:00:00\", \"{c}\", \"x\"\nrusak,bukan-hash\n"
    );
    assert_eq!(db.load_text(&text), 3);
    assert_eq!(db.lookup(&b).unwrap().name, "Evil.Thing");
    assert_eq!(db.lookup(&b).unwrap().category, "Trojan");
    assert!(db.lookup(&a).is_some());
    assert!(db.lookup(&c).is_some());
}

#[test]
fn state_stats_and_log() {
    let mut s = State::default();
    s.add_scanned(10);
    s.add_threat("Trojan");
    s.add_removed();
    s.log("Scan", "10 file", "clean");
    assert_eq!(s.total_scanned, 10);
    assert_eq!(s.by_category["Trojan"], 1);
    assert_eq!(s.by_day.values().sum::<u32>(), 1);
    let p = tmp("state").join("s.json");
    s.save(&p).unwrap();
    assert_eq!(State::load(&p).log.len(), 1);
}
