use crate::model::*;
use crate::signatures::SignatureDb;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};
use walkdir::WalkDir;

#[derive(Clone, Debug)]
pub struct ScanOptions {
    /// File lebih besar dari ini dilewati.
    pub max_size: u64,
    /// Folder yang tidak boleh dipindai (misalnya folder karantina).
    pub exclude: Vec<PathBuf>,
}

impl Default for ScanOptions {
    fn default() -> Self {
        Self { max_size: 200 * 1024 * 1024, exclude: vec![] }
    }
}

const DOC_EXT: &[&str] = &[
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "jpg", "jpeg", "png", "gif", "mp3", "mp4",
];
const EXEC_EXT: &[&str] = &[
    "exe", "scr", "bat", "cmd", "com", "pif", "vbs", "js", "jse", "wsf", "ps1", "msi", "jar",
];

fn is_pe(h: &[u8]) -> bool {
    if h.len() < 0x40 || &h[..2] != b"MZ" {
        return false;
    }
    let off = u32::from_le_bytes([h[0x3c], h[0x3d], h[0x3e], h[0x3f]]) as usize;
    off + 4 <= h.len() && &h[off..off + 4] == b"PE\0\0"
}

fn is_elf(h: &[u8]) -> bool {
    h.len() >= 4 && h[0] == 0x7f && &h[1..4] == b"ELF"
}

/// Heuristik ringan dengan false-positive rendah.
fn heuristic(path: &Path, header: &[u8]) -> Option<(&'static str, &'static str, &'static str)> {
    let name = path.file_name()?.to_string_lossy().to_ascii_lowercase();
    let parts: Vec<&str> = name.split('.').collect();
    if parts.len() >= 3 {
        let last = parts[parts.len() - 1];
        let prev = parts[parts.len() - 2];
        if EXEC_EXT.contains(&last) && DOC_EXT.contains(&prev) {
            return Some((
                "Heuristic.DoubleExtension",
                "Suspicious",
                "Ekstensi ganda: file program menyamar sebagai dokumen/gambar",
            ));
        }
    }
    if let Some(ext) = parts.last() {
        if parts.len() >= 2 && DOC_EXT.contains(ext) && (is_pe(header) || is_elf(header)) {
            return Some((
                "Heuristic.DisguisedExecutable",
                "Suspicious",
                "Isi file adalah program, tetapi ekstensinya dokumen/gambar",
            ));
        }
    }
    None
}

/// Periksa satu file. `Ok(None)` berarti bersih atau dilewati.
pub fn scan_file(path: &Path, db: &SignatureDb, max_size: u64) -> io::Result<Option<Threat>> {
    let meta = std::fs::symlink_metadata(path)?;
    if !meta.is_file() || meta.len() > max_size {
        return Ok(None);
    }
    let (sha, header) = hash_and_header(path)?;
    let mk = |name: &str, category: &str, severity: &str, reason: &str| Threat {
        id: new_id(),
        name: name.to_string(),
        path: path.display().to_string(),
        category: category.to_string(),
        severity: severity.to_string(),
        sha256: sha.clone(),
        reason: reason.to_string(),
        detected_at: now_secs(),
    };
    if let Some(info) = db.lookup(&sha) {
        return Ok(Some(mk(&info.name, &info.category, "high", "Cocok dengan signature")));
    }
    if let Some((name, cat, reason)) = heuristic(path, &header) {
        return Ok(Some(mk(name, cat, "medium", reason)));
    }
    Ok(None)
}

fn walk<'a>(root: &'a Path, exclude: &'a [PathBuf]) -> impl Iterator<Item = walkdir::DirEntry> + 'a {
    WalkDir::new(root)
        .follow_links(false)
        .into_iter()
        .filter_entry(move |e| !exclude.iter().any(|x| e.path().starts_with(x)))
        .filter_map(Result::ok)
        .filter(|e| e.file_type().is_file())
}

/// Pindai banyak folder/file. `progress` dipanggil berkala; `cancel` menghentikan scan.
pub fn scan_paths(
    targets: &[PathBuf],
    db: &SignatureDb,
    opts: &ScanOptions,
    cancel: &AtomicBool,
    progress: &mut dyn FnMut(&Progress),
) -> ScanSummary {
    let started = Instant::now();
    let mut prog = Progress { phase: "counting".into(), ..Default::default() };
    progress(&prog);

    // Tahap 1: hitung file supaya UI bisa menampilkan persentase.
    let mut total = 0u64;
    'count: for t in targets {
        for _ in walk(t, &opts.exclude) {
            if cancel.load(Ordering::Relaxed) {
                break 'count;
            }
            total += 1;
            if total % 2000 == 0 {
                prog.total = total;
                progress(&prog);
            }
        }
    }
    prog.phase = "scanning".into();
    prog.total = total;
    progress(&prog);

    // Tahap 2: hash + cocokkan.
    let mut sum = ScanSummary::default();
    let mut last_emit = Instant::now();
    'scan: for t in targets {
        for entry in walk(t, &opts.exclude) {
            if cancel.load(Ordering::Relaxed) {
                sum.cancelled = true;
                break 'scan;
            }
            let path = entry.path();
            match scan_file(path, db, opts.max_size) {
                Ok(Some(th)) => sum.threats.push(th),
                Ok(None) => {}
                Err(_) => sum.skipped += 1,
            }
            sum.scanned += 1;
            if last_emit.elapsed() >= Duration::from_millis(100) {
                prog.scanned = sum.scanned;
                prog.threats = sum.threats.len() as u32;
                prog.current = path.display().to_string();
                progress(&prog);
                last_emit = Instant::now();
            }
        }
    }
    prog.scanned = sum.scanned;
    prog.threats = sum.threats.len() as u32;
    progress(&prog);
    sum.duration_ms = started.elapsed().as_millis() as u64;
    sum
}
