use crate::model::*;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const KEY: u8 = 0x5A;

/// Salin dengan XOR sederhana supaya file berbahaya tidak bisa langsung dijalankan
/// dan tidak memicu scanner lain. Operasi ini simetris (dipakai juga untuk memulihkan).
fn xor_copy(src: &Path, dst: &Path) -> io::Result<()> {
    let mut r = File::open(src)?;
    let mut w = File::create(dst)?;
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = r.read(&mut buf)?;
        if n == 0 {
            break;
        }
        for b in &mut buf[..n] {
            *b ^= KEY;
        }
        w.write_all(&buf[..n])?;
    }
    w.flush()
}

pub struct Quarantine {
    dir: PathBuf,
}

impl Quarantine {
    pub fn new(dir: PathBuf) -> io::Result<Self> {
        fs::create_dir_all(&dir)?;
        Ok(Self { dir })
    }

    pub fn dir(&self) -> &Path {
        &self.dir
    }

    fn index_path(&self) -> PathBuf {
        self.dir.join("index.json")
    }

    fn stored(&self, id: &str) -> PathBuf {
        self.dir.join(format!("{id}.qbin"))
    }

    pub fn list(&self) -> Vec<QuarantineItem> {
        fs::read_to_string(self.index_path())
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default()
    }

    fn save(&self, items: &[QuarantineItem]) -> io::Result<()> {
        let json = serde_json::to_string_pretty(items).map_err(io::Error::other)?;
        fs::write(self.index_path(), json)
    }

    pub fn add(&self, t: &Threat) -> io::Result<QuarantineItem> {
        let src = Path::new(&t.path);
        let size = fs::metadata(src)?.len();
        let id = new_id();
        xor_copy(src, &self.stored(&id))?;
        fs::remove_file(src)?;
        let item = QuarantineItem {
            id,
            name: t.name.clone(),
            category: t.category.clone(),
            severity: t.severity.clone(),
            original_path: t.path.clone(),
            sha256: t.sha256.clone(),
            size,
            quarantined_at: now_secs(),
        };
        let mut items = self.list();
        items.push(item.clone());
        self.save(&items)?;
        Ok(item)
    }

    pub fn restore(&self, id: &str) -> io::Result<PathBuf> {
        let mut items = self.list();
        let pos = items
            .iter()
            .position(|i| i.id == id)
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "item tidak ditemukan"))?;
        let item = items.remove(pos);
        let mut dest = PathBuf::from(&item.original_path);
        if let Some(parent) = dest.parent() {
            fs::create_dir_all(parent)?;
        }
        if dest.exists() {
            let mut name = dest.file_name().unwrap_or_default().to_os_string();
            name.push(".restored");
            dest.set_file_name(name);
        }
        xor_copy(&self.stored(id), &dest)?;
        let _ = fs::remove_file(self.stored(id));
        self.save(&items)?;
        Ok(dest)
    }

    pub fn delete(&self, id: &str) -> io::Result<QuarantineItem> {
        let mut items = self.list();
        let pos = items
            .iter()
            .position(|i| i.id == id)
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "item tidak ditemukan"))?;
        let item = items.remove(pos);
        let _ = fs::remove_file(self.stored(id));
        self.save(&items)?;
        Ok(item)
    }
}
