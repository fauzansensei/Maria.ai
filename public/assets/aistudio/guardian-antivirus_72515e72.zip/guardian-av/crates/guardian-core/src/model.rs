use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{self, Read};
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct Threat {
    pub id: String,
    pub name: String,
    pub path: String,
    pub category: String,
    /// "high" (signature) atau "medium" (heuristik)
    pub severity: String,
    pub sha256: String,
    pub reason: String,
    pub detected_at: i64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct QuarantineItem {
    pub id: String,
    pub name: String,
    pub category: String,
    pub severity: String,
    pub original_path: String,
    pub sha256: String,
    pub size: u64,
    pub quarantined_at: i64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct LogEntry {
    pub ts: i64,
    pub title: String,
    pub detail: String,
    /// "clean" | "threat" | "removed" | "restored" | "info"
    pub status: String,
}

#[derive(Serialize, Clone, Debug, Default)]
pub struct Progress {
    /// "counting" | "scanning"
    pub phase: String,
    pub total: u64,
    pub scanned: u64,
    pub threats: u32,
    pub current: String,
}

#[derive(Serialize, Clone, Debug, Default)]
pub struct ScanSummary {
    pub scanned: u64,
    pub skipped: u64,
    pub threats: Vec<Threat>,
    pub cancelled: bool,
    pub duration_ms: u64,
}

pub fn now_secs() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

static COUNTER: AtomicU64 = AtomicU64::new(0);

pub fn new_id() -> String {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("{:x}{:04x}", nanos, COUNTER.fetch_add(1, Ordering::Relaxed) & 0xffff)
}

pub fn to_hex(bytes: &[u8]) -> String {
    const H: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(H[(b >> 4) as usize] as char);
        s.push(H[(b & 0xf) as usize] as char);
    }
    s
}

/// Hitung SHA-256 file secara streaming dan kembalikan juga 4 KB pertama (untuk heuristik).
pub fn hash_and_header(path: &Path) -> io::Result<(String, Vec<u8>)> {
    let mut f = File::open(path)?;
    let mut hasher = Sha256::new();
    let mut buf = vec![0u8; 64 * 1024];
    let mut header: Vec<u8> = Vec::new();
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        if header.is_empty() {
            header.extend_from_slice(&buf[..n.min(4096)]);
        }
        hasher.update(&buf[..n]);
    }
    Ok((to_hex(&hasher.finalize()), header))
}

pub fn sha256_file(path: &Path) -> io::Result<String> {
    hash_and_header(path).map(|(h, _)| h)
}
