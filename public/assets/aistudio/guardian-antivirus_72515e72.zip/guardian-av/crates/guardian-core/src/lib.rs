//! Guardian core: logika antivirus yang tidak bergantung pada UI/platform.
pub mod model;
pub mod quarantine;
pub mod scanner;
pub mod signatures;
pub mod state;

pub use model::*;
pub use quarantine::Quarantine;
pub use scanner::{scan_file, scan_paths, ScanOptions};
pub use signatures::SignatureDb;
pub use state::State;
