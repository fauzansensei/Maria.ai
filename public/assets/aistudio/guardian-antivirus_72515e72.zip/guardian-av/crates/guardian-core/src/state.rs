use crate::model::*;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::fs;
use std::io;
use std::path::Path;

const MAX_LOG: usize = 200;

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
pub struct State {
    pub total_scanned: u64,
    pub total_removed: u64,
    /// hari sejak epoch (detik / 86400) -> jumlah ancaman terdeteksi
    pub by_day: BTreeMap<u64, u32>,
    pub by_category: BTreeMap<String, u32>,
    pub log: Vec<LogEntry>,
}

impl State {
    pub fn load(path: &Path) -> Self {
        fs::read_to_string(path)
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default()
    }

    pub fn save(&self, path: &Path) -> io::Result<()> {
        let json = serde_json::to_string(self).map_err(io::Error::other)?;
        fs::write(path, json)
    }

    pub fn log(&mut self, title: &str, detail: &str, status: &str) {
        self.log.insert(
            0,
            LogEntry {
                ts: now_secs(),
                title: title.into(),
                detail: detail.into(),
                status: status.into(),
            },
        );
        self.log.truncate(MAX_LOG);
    }

    pub fn add_scanned(&mut self, n: u64) {
        self.total_scanned += n;
    }

    pub fn add_threat(&mut self, category: &str) {
        let day = (now_secs() / 86_400) as u64;
        *self.by_day.entry(day).or_insert(0) += 1;
        *self.by_category.entry(category.to_string()).or_insert(0) += 1;
        // simpan hanya 60 hari terakhir
        while self.by_day.len() > 60 {
            let first = *self.by_day.keys().next().unwrap();
            self.by_day.remove(&first);
        }
    }

    pub fn add_removed(&mut self) {
        self.total_removed += 1;
    }
}
