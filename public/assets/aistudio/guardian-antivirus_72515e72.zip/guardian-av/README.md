# Guardian Antivirus

Antivirus ringan berbasis **hash signature + heuristik**, satu kode untuk **Windows, Linux, dan Android**
(Tauri 2: UI React, mesin scanner Rust). Tampilan bergaya AdGuard.

## Fitur

- Quick scan (Downloads, Desktop, Temp), Full scan (folder home), Scan folder pilihan
- Real-time protection: memantau Downloads & Desktop, file baru langsung diperiksa
- Karantina (file diacak XOR, bisa dipulihkan atau dihapus permanen)
- Heuristik: ekstensi ganda (`laporan.pdf.exe`) dan program yang menyamar jadi dokumen/gambar
- Check file reputation (SHA-256 satu file)
- Update signature dari URL daftar hash (`src/config.ts`)
- Statistik 7 hari, rincian kategori, log aktivitas

## Struktur

```
crates/guardian-core/   mesin: signature, scanner, quarantine, state  (Rust, ada unit test)
src-tauri/              aplikasi Tauri: command, real-time watcher, event ke UI
src/                    UI React + TypeScript
```

## Prasyarat

| Platform | Kebutuhan |
|---|---|
| Semua | Node 20+, pnpm (atau npm), Rust **1.85+** (rustup). Tidak perlu `cargo install tauri-cli`, cukup `@tauri-apps/cli` dari npm |
| Windows | Microsoft C++ Build Tools, WebView2 (sudah ada di Windows 10/11) |
| Linux (Debian/Ubuntu) | `sudo apt install libwebkit2gtk-4.1-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev libsoup-3.0-dev build-essential pkg-config` |
| Android | Android Studio + SDK/NDK, `JAVA_HOME`, target Rust Android |

## Menjalankan

`Cargo.lock` sudah disertakan dan dipilih agar cocok dengan Rust 1.85. Jangan dihapus kecuali kamu memakai Rust terbaru.

```bash
pnpm install
pnpm tauri dev        # mode pengembangan
pnpm tauri build      # installer (.msi/.exe, .deb/.AppImage)
```

Uji mesin scanner saja (tanpa Tauri):

```bash
cargo test -p guardian-core
```

## Mencoba dengan aman (file EICAR)

EICAR adalah file uji standar antivirus, bukan malware. Buat file teks berisi satu baris ini,
simpan di folder Downloads dan lihat Guardian mengkarantinanya:

```
X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*
```

## Android

```bash
pnpm tauri android init
pnpm tauri android dev
```

Batasan Android: aplikasi hanya bisa memindai file yang diizinkan sistem (Download, media, penyimpanan
bersama). Untuk memindai seluruh `/sdcard` perlu izin *All files access*. Memindai APK aplikasi terpasang
butuh plugin Kotlin (`PackageManager`) yang belum ada di proyek ini. iOS tidak didukung.

## Batasan jujur

- Ini scanner **signature hash + heuristik ringan**, bukan pengganti Defender/Bitdefender. Hanya malware
  yang hash-nya ada di daftar yang terdeteksi (selain pola heuristik di atas).
- Real-time memakai file watcher tingkat aplikasi: file diperiksa **setelah** tertulis, bukan diblokir
  sebelum dijalankan (itu butuh driver kernel/minifilter).
- Folder yang dipantau real-time: Downloads dan Desktop. Ubah di `watch_paths()` di `src-tauri/src/lib.rs`.
- Quick/Full scan melewati file di atas 200 MB (`ScanOptions::max_size`).
- Database signature kosong di awal (hanya EICAR). Isi lewat tombol *Update signatures* atau taruh file
  `signatures.txt` di folder data aplikasi.
