/**
 * Sumber daftar hash malware (satu SHA-256 per baris; komentar diawali #).
 * Default: ekspor teks MalwareBazaar (abuse.ch). Layanan ini bisa mewajibkan Auth-Key;
 * jika begitu, ganti dengan URL feed milikmu sendiri.
 */
export const SIGNATURE_URL = "https://bazaar.abuse.ch/export/txt/sha256/recent/";
