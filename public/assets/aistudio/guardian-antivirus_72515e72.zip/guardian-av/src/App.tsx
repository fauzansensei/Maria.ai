import { useCallback, useEffect, useMemo, useState } from "react";
import { api, on, type Progress, type ScanDone, type RealtimeHit, type Snapshot } from "./api";
import { SIGNATURE_URL } from "./config";
import * as I from "./icons";

type Extra = "quar" | "log" | null;
type Msg = { text: string; kind: "ok" | "w" | "e" } | null;

const nf = new Intl.NumberFormat("id-ID");
const fmtTime = (ts: number) =>
  new Date(ts * 1000).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
const CAT_COLORS = ["#f43f5e", "#f59e0b", "#0ea5e9", "#8b5cf6", "#10b981"];

export default function App() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [scan, setScan] = useState<Progress | null>(null);
  const [tab, setTab] = useState<"actions" | "stats">("actions");
  const [extra, setExtra] = useState<Extra>(null);
  const [msg, setMsg] = useState<Msg>(null);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => setSnap(await api.snapshot()), []);

  useEffect(() => {
    refresh().catch((e) => setMsg({ text: String(e), kind: "e" }));
    const subs = [
      on<Progress>("scan-progress", setScan),
      on<ScanDone>("scan-done", (d) => {
        setScan(null);
        refresh();
        setMsg(
          d.cancelled
            ? { text: "Scan dibatalkan", kind: "w" }
            : d.found
            ? { text: `${d.found} ancaman ditemukan, ${d.quarantined} dikarantina`, kind: "w" }
            : { text: `Selesai: ${nf.format(d.scanned)} file, tidak ada ancaman`, kind: "ok" }
        );
      }),
      on<RealtimeHit>("threat-found", (h) => {
        refresh();
        setMsg({ text: `Real-time: ${h.name} ${h.quarantined ? "dikarantina" : "terdeteksi"}`, kind: "w" });
      }),
    ];
    return () => {
      subs.forEach((p) => p.then((un) => un()));
    };
  }, [refresh]);

  const run = async (fn: () => Promise<void>) => {
    setMsg(null);
    try {
      await fn();
    } catch (e) {
      setMsg({ text: String(e), kind: "e" });
    }
  };

  const startScan = (kind: "quick" | "full" | "folder") =>
    run(async () => {
      let path: string | undefined;
      if (kind === "folder") {
        const p = await api.pickFolder();
        if (!p) return;
        path = p;
      }
      setExtra(null);
      setScan({ phase: "counting", total: 0, scanned: 0, threats: 0, current: "" });
      try {
        await api.startScan(kind, path);
      } catch (e) {
        setScan(null);
        throw e;
      }
    });

  const toggleRealtime = () =>
    run(async () => {
      if (!snap) return;
      await api.setRealtime(!snap.realtime);
      await refresh();
    });

  const checkFile = () =>
    run(async () => {
      const p = await api.pickFile();
      if (!p) return;
      setExtra(null);
      const r = await api.checkFile(p);
      setMsg(
        r.verdict === "threat"
          ? { text: `Berbahaya: ${r.name} (${r.reason})`, kind: "e" }
          : { text: `Aman. SHA-256 ${r.sha256.slice(0, 16)}… tidak cocok dengan signature`, kind: "ok" }
      );
    });

  const updateSigs = () =>
    run(async () => {
      setBusy(true);
      setMsg({ text: "Mengunduh signature…", kind: "w" });
      try {
        const n = await api.updateSignatures(SIGNATURE_URL);
        setMsg({ text: `Signature diperbarui: ${nf.format(n)} entri`, kind: "ok" });
        await refresh();
      } finally {
        setBusy(false);
      }
    });

  const toggleTheme = () => {
    const r = document.documentElement;
    const dark = r.dataset.theme ? r.dataset.theme === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    r.dataset.theme = dark ? "light" : "dark";
  };

  const week = useMemo(() => {
    const today = Math.floor(Date.now() / 86_400_000);
    const days = Array.from({ length: 7 }, (_, i) => today - 6 + i);
    return days.map((d) => ({
      d,
      v: snap?.byDay[String(d)] ?? 0,
      label: new Date(d * 86_400_000).toLocaleDateString("id-ID", { weekday: "short", timeZone: "UTC" }),
    }));
  }, [snap]);

  const cats = useMemo(() => {
    const entries = Object.entries(snap?.byCategory ?? {}).sort((a, b) => b[1] - a[1]);
    const sum = entries.reduce((a, [, v]) => a + v, 0) || 1;
    return entries.map(([n, v], i) => ({ n, pct: Math.round((v / sum) * 100), color: CAT_COLORS[i % CAT_COLORS.length] }));
  }, [snap]);

  if (!snap) return <main className="card"><div className="empty">{msg?.text ?? "Memuat…"}</div></main>;

  const threats = snap.quarantine.length;
  const scanning = scan !== null || snap.scanning;
  const pct = scan && scan.phase === "scanning" && scan.total > 0 ? Math.min(100, Math.round((scan.scanned / scan.total) * 100)) : 0;
  const maxBar = Math.max(1, ...week.map((w) => w.v));

  return (
    <main className="card">
      <header>
        <div className="brand"><I.Logo /> Guardian</div>
        <button className="ibtn" onClick={toggleTheme} aria-label="Ganti tema" title="Ganti tema"><I.Sun /></button>
      </header>

      <section className="hero">
        <div className="device">{snap.device} · {snap.platform}</div>
        <div className={`count ${threats ? "bad" : ""}`}>Threats: {threats}</div>
        <div className="total">Total scanned: {nf.format(snap.totalScanned)} · Removed: {snap.totalRemoved}</div>
      </section>

      <button
        className={`toggle ${!snap.realtime ? "off" : threats ? "warn" : ""}`}
        onClick={toggleRealtime}
        aria-label="Perlindungan real-time"
      >
        {!snap.realtime ? <I.ShieldOff /> : threats ? <I.ShieldBad /> : <I.ShieldOk />}
      </button>
      <div className="state">
        {!snap.realtime ? "Perlindungan real-time dimatikan" : threats ? "Ancaman ditahan di karantina" : "Perlindungan real-time aktif"}
      </div>

      <nav className="tabs">
        <button className={tab === "actions" ? "on" : ""} onClick={() => setTab("actions")}>Actions</button>
        <button className={tab === "stats" ? "on" : ""} onClick={() => setTab("stats")}>Statistics</button>
      </nav>

      {tab === "actions" ? (
        <>
          <ul className="list">
            <li className={scanning ? "disabled" : ""} onClick={() => startScan("quick")}><I.Bolt />Quick scan</li>
            <li className={scanning ? "disabled" : ""} onClick={() => startScan("full")}><I.Scan />Full scan</li>
            <li className={scanning ? "disabled" : ""} onClick={() => startScan("folder")}><I.Folder />Scan folder…</li>
            <li onClick={() => setExtra(extra === "quar" ? null : "quar")}>
              <I.Box />Open quarantine{threats ? <span className="badge">{threats}</span> : null}
            </li>
            <li onClick={() => setExtra(extra === "log" ? null : "log")}><I.List />Open scan log</li>
            <li onClick={checkFile}><I.Info />Check file reputation</li>
            <li className={busy ? "disabled" : ""} onClick={updateSigs}><I.Refresh />Update signatures</li>
          </ul>

          {scan && (
            <div className="prog">
              <div className="top">
                <b>{scan.phase === "counting" ? `Menghitung file… ${nf.format(scan.total)}` : `Memindai ${nf.format(scan.scanned)} / ${nf.format(scan.total)}`}</b>
                <span>{scan.phase === "scanning" ? `${pct}%` : ""}</span>
                <button className="mini" onClick={() => api.cancelScan()}>Batal</button>
              </div>
              <div className="track"><div className={`fill ${scan.phase === "counting" ? "indet" : ""}`} style={scan.phase === "scanning" ? { width: `${pct}%` } : undefined} /></div>
              <div className="path"><bdo dir="ltr">{scan.current}</bdo></div>
            </div>
          )}

          {extra === "quar" && (
            <div className="log">
              {snap.quarantine.length === 0 && <div className="empty">Karantina kosong</div>}
              {snap.quarantine.map((q) => (
                <div className="row" key={q.id}>
                  <div className="nm"><b>{q.name}</b><small>{q.original_path}</small></div>
                  <div className="btns">
                    <button className="mini" onClick={() => run(async () => { await api.restore(q.id); await refresh(); })}>Pulihkan</button>
                    <button className="mini del" onClick={() => run(async () => { await api.remove(q.id); await refresh(); })}>Hapus</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {extra === "log" && (
            <div className="log">
              {snap.log.length === 0 && <div className="empty">Belum ada aktivitas</div>}
              {snap.log.slice(0, 40).map((l, i) => (
                <div className="row" key={i}>
                  <div className="nm"><b>{l.title}</b><small>{fmtTime(l.ts)} · {l.detail}</small></div>
                  <span className={`tag ${l.status}`}>{l.status}</span>
                </div>
              ))}
            </div>
          )}

          {msg && <div className={`toast ${msg.kind === "ok" ? "" : msg.kind}`}>{msg.text}</div>}
          <div className="sig">{nf.format(snap.signatureCount)} signature dimuat</div>
        </>
      ) : (
        <div>
          <div className="bars">
            {week.map((w, i) => (
              <div key={w.d} className={`bar ${i === 6 ? "today" : ""}`} style={{ height: `${Math.max(4, (w.v / maxBar) * 100)}%` }} title={`${w.v} ancaman`} />
            ))}
          </div>
          <div className="days">{week.map((w) => <span key={w.d}>{w.label}</span>)}</div>
          <div className="cats">
            {cats.length === 0 && <div className="empty">Belum ada ancaman tercatat</div>}
            {cats.map((c) => (
              <div className="cat" key={c.n}>
                <span>{c.n}</span>
                <div className="track"><div className="fill" style={{ width: `${c.pct}%`, background: c.color }} /></div>
                <span>{c.pct}%</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
