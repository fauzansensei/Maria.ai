use guardian_core::{
    is_due, now_secs, sha256_file, signatures, LogEntry, Quarantine, QuarantineItem, ScanOptions, Settings,
    SignatureDb, State, Threat,
};
use notify::{EventKind, RecursiveMode, Watcher};
use serde::Serialize;
use std::collections::{BTreeMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc, Mutex, RwLock};
use std::time::Duration;
use tauri::{AppHandle, Emitter, Manager, State as TauriState};

const MAX_FILE: u64 = 200 * 1024 * 1024;

// ───────────────────────── state bersama ─────────────────────────

struct Inner {
    data_dir: PathBuf,
    db: RwLock<SignatureDb>,
    state: Mutex<State>,
    quarantine: Mutex<Quarantine>,
    settings: Mutex<Settings>,
}

impl Inner {
    fn with_settings<R>(&self, f: impl FnOnce(&mut Settings) -> R) -> R {
        let mut s = self.settings.lock().unwrap();
        let r = f(&mut s);
        let _ = s.save(&self.data_dir.join("settings.json"));
        r
    }

    fn with_state<R>(&self, f: impl FnOnce(&mut State) -> R) -> R {
        let mut s = self.state.lock().unwrap();
        let r = f(&mut s);
        let _ = s.save(&self.data_dir.join("state.json"));
        r
    }

    /// Pindahkan semua ancaman ke karantina, catat statistik. Mengembalikan jumlah yang berhasil.
    fn quarantine_threats(&self, threats: &[Threat]) -> usize {
        let mut moved = 0;
        for t in threats {
            let ok = self.quarantine.lock().unwrap().add(t).is_ok();
            self.with_state(|s| {
                s.add_threat(&t.category);
                if ok {
                    s.log(&format!("Dikarantina: {}", t.name), &t.path, "threat");
                } else {
                    s.log(&format!("Gagal mengkarantina: {}", t.name), &t.path, "info");
                }
            });
            if ok {
                moved += 1;
            }
        }
        moved
    }
}

struct Shared {
    inner: Arc<Inner>,
    cancel: Arc<AtomicBool>,
    scanning: Arc<AtomicBool>,
    watcher: Mutex<Option<notify::RecommendedWatcher>>,
}

// ───────────────────────── payload ke UI ─────────────────────────

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Snapshot {
    platform: String,
    device: String,
    realtime: bool,
    scanning: bool,
    signature_count: usize,
    quarantine: Vec<QuarantineItem>,
    total_scanned: u64,
    total_removed: u64,
    by_day: BTreeMap<u64, u32>,
    by_category: BTreeMap<String, u32>,
    log: Vec<LogEntry>,
    settings: Settings,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ScanDone {
    label: String,
    scanned: u64,
    found: usize,
    quarantined: usize,
    cancelled: bool,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct RealtimeHit {
    name: String,
    path: String,
    quarantined: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct CheckResult {
    sha256: String,
    verdict: String,
    name: Option<String>,
    reason: Option<String>,
}

// ───────────────────────── util ─────────────────────────

fn device_name() -> String {
    std::env::var("COMPUTERNAME")
        .or_else(|_| std::env::var("HOSTNAME"))
        .ok()
        .or_else(|| std::fs::read_to_string("/etc/hostname").ok().map(|s| s.trim().to_string()))
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "Perangkat ini".into())
}

fn existing(paths: Vec<Option<PathBuf>>) -> Vec<PathBuf> {
    paths.into_iter().flatten().filter(|p| p.exists()).collect()
}

fn quick_targets(app: &AppHandle) -> Vec<PathBuf> {
    let p = app.path();
    let mut v = existing(vec![p.download_dir().ok(), p.desktop_dir().ok(), p.temp_dir().ok()]);
    if v.is_empty() {
        v = existing(vec![Some(PathBuf::from("/sdcard/Download"))]);
    }
    v
}

fn full_targets(app: &AppHandle) -> Vec<PathBuf> {
    let p = app.path();
    let mut v = existing(vec![p.home_dir().ok(), p.temp_dir().ok()]);
    if v.is_empty() {
        v = existing(vec![Some(PathBuf::from("/sdcard"))]);
    }
    v
}

fn watch_paths(app: &AppHandle) -> Vec<PathBuf> {
    let p = app.path();
    existing(vec![p.download_dir().ok(), p.desktop_dir().ok()])
}

// ───────────────────────── real-time ─────────────────────────

fn check_realtime(app: &AppHandle, inner: &Arc<Inner>, path: &Path) {
    if !path.is_file() {
        return;
    }
    let mut found: Option<Threat> = None;
    for _ in 0..3 {
        let res = {
            let db = inner.db.read().unwrap();
            guardian_core::scan_file(path, &db, MAX_FILE)
        };
        match res {
            Ok(r) => {
                found = r;
                break;
            }
            // file mungkin masih sedang ditulis: coba lagi sebentar
            Err(_) => std::thread::sleep(Duration::from_millis(400)),
        }
    }
    if let Some(t) = found {
        let moved = inner.quarantine_threats(std::slice::from_ref(&t));
        let _ = app.emit(
            "threat-found",
            RealtimeHit { name: t.name, path: t.path, quarantined: moved > 0 },
        );
    }
}

fn start_watcher(
    app: AppHandle,
    inner: Arc<Inner>,
    paths: Vec<PathBuf>,
) -> Result<notify::RecommendedWatcher, String> {
    let (tx, rx) = mpsc::channel::<PathBuf>();
    let data_dir = inner.data_dir.clone();
    let mut watcher = notify::recommended_watcher(move |res: notify::Result<notify::Event>| {
        if let Ok(ev) = res {
            if matches!(ev.kind, EventKind::Create(_) | EventKind::Modify(_)) {
                for p in ev.paths {
                    if !p.starts_with(&data_dir) {
                        let _ = tx.send(p);
                    }
                }
            }
        }
    })
    .map_err(|e| e.to_string())?;

    let watched = paths
        .iter()
        .filter(|p| watcher.watch(p, RecursiveMode::Recursive).is_ok())
        .count();
    if watched == 0 {
        return Err("Tidak ada folder yang bisa dipantau".into());
    }

    // Worker: kumpulkan event beruntun, buang duplikat, lalu periksa.
    std::thread::spawn(move || {
        while let Ok(first) = rx.recv() {
            let mut batch: HashSet<PathBuf> = HashSet::new();
            batch.insert(first);
            while let Ok(p) = rx.recv_timeout(Duration::from_millis(600)) {
                batch.insert(p);
                if batch.len() > 200 {
                    break;
                }
            }
            for p in batch {
                check_realtime(&app, &inner, &p);
            }
        }
        // channel tertutup (watcher dilepas) -> thread selesai
    });
    Ok(watcher)
}

// ───────────────────────── commands ─────────────────────────

#[tauri::command]
fn get_snapshot(shared: TauriState<Shared>) -> Snapshot {
    let inner = &shared.inner;
    let st = inner.state.lock().unwrap().clone();
    Snapshot {
        platform: std::env::consts::OS.to_string(),
        device: device_name(),
        realtime: shared.watcher.lock().unwrap().is_some(),
        scanning: shared.scanning.load(Ordering::SeqCst),
        signature_count: inner.db.read().unwrap().len(),
        quarantine: inner.quarantine.lock().unwrap().list(),
        total_scanned: st.total_scanned,
        total_removed: st.total_removed,
        by_day: st.by_day,
        by_category: st.by_category,
        log: st.log,
        settings: inner.settings.lock().unwrap().clone(),
    }
}

/// Jalankan scan di thread terpisah. Mengembalikan false jika scan lain sedang berjalan.
fn spawn_scan(
    app: AppHandle,
    inner: Arc<Inner>,
    cancel: Arc<AtomicBool>,
    scanning: Arc<AtomicBool>,
    label: String,
    targets: Vec<PathBuf>,
) -> bool {
    if scanning.swap(true, Ordering::SeqCst) {
        return false;
    }
    cancel.store(false, Ordering::SeqCst);
    std::thread::spawn(move || {
        let mut opts = ScanOptions::default();
        opts.exclude.push(inner.data_dir.clone());
        let sum = {
            let db = inner.db.read().unwrap();
            let a = app.clone();
            guardian_core::scan_paths(&targets, &db, &opts, &cancel, &mut |p| {
                let _ = a.emit("scan-progress", p);
            })
        };
        let quarantined = inner.quarantine_threats(&sum.threats);
        inner.with_state(|s| {
            s.add_scanned(sum.scanned);
            let title = format!("{} {}", label, if sum.cancelled { "dibatalkan" } else { "selesai" });
            let detail = format!("{} file, {} ancaman, {} ms", sum.scanned, sum.threats.len(), sum.duration_ms);
            s.log(&title, &detail, if sum.threats.is_empty() { "clean" } else { "threat" });
        });
        scanning.store(false, Ordering::SeqCst);
        let _ = app.emit(
            "scan-done",
            ScanDone {
                label,
                scanned: sum.scanned,
                found: sum.threats.len(),
                quarantined,
                cancelled: sum.cancelled,
            },
        );
    });
    true
}

#[tauri::command]
fn start_scan(
    app: AppHandle,
    shared: TauriState<Shared>,
    kind: String,
    path: Option<String>,
) -> Result<(), String> {
    let (label, targets): (&str, Vec<PathBuf>) = match kind.as_str() {
        "quick" => ("Quick scan", quick_targets(&app)),
        "full" => ("Full scan", full_targets(&app)),
        "folder" => {
            let p = PathBuf::from(path.ok_or("Folder belum dipilih")?);
            if !p.exists() {
                return Err("Folder tidak ditemukan".into());
            }
            ("Scan folder", vec![p])
        }
        _ => return Err("Jenis scan tidak dikenal".into()),
    };
    if targets.is_empty() {
        return Err("Tidak ada lokasi yang bisa dipindai di perangkat ini".into());
    }
    let started = spawn_scan(
        app,
        shared.inner.clone(),
        shared.cancel.clone(),
        shared.scanning.clone(),
        label.to_string(),
        targets,
    );
    if started { Ok(()) } else { Err("Scan lain masih berjalan".into()) }
}

#[tauri::command]
fn cancel_scan(shared: TauriState<Shared>) {
    shared.cancel.store(true, Ordering::SeqCst);
}

#[tauri::command]
fn set_realtime(app: AppHandle, shared: TauriState<Shared>, on: bool) -> Result<bool, String> {
    let mut w = shared.watcher.lock().unwrap();
    if on {
        if w.is_none() {
            *w = Some(start_watcher(app.clone(), shared.inner.clone(), watch_paths(&app))?);
        }
    } else {
        *w = None;
    }
    Ok(w.is_some())
}

#[tauri::command]
fn quarantine_restore(shared: TauriState<Shared>, id: String) -> Result<String, String> {
    let inner = &shared.inner;
    let dest = inner.quarantine.lock().unwrap().restore(&id).map_err(|e| e.to_string())?;
    let d = dest.display().to_string();
    inner.with_state(|s| s.log("Dipulihkan dari karantina", &d, "restored"));
    Ok(d)
}

#[tauri::command]
fn quarantine_delete(shared: TauriState<Shared>, id: String) -> Result<(), String> {
    let inner = &shared.inner;
    let item = inner.quarantine.lock().unwrap().delete(&id).map_err(|e| e.to_string())?;
    inner.with_state(|s| {
        s.add_removed();
        s.log(&format!("Dihapus permanen: {}", item.name), &item.original_path, "removed");
    });
    Ok(())
}

#[tauri::command]
fn check_file(shared: TauriState<Shared>, path: String) -> Result<CheckResult, String> {
    let p = PathBuf::from(&path);
    let sha = sha256_file(&p).map_err(|e| e.to_string())?;
    let db = shared.inner.db.read().unwrap();
    let hit = guardian_core::scan_file(&p, &db, u64::MAX).map_err(|e| e.to_string())?;
    Ok(match hit {
        Some(t) => CheckResult { sha256: sha, verdict: "threat".into(), name: Some(t.name), reason: Some(t.reason) },
        None => CheckResult { sha256: sha, verdict: "clean".into(), name: None, reason: None },
    })
}

/// Unduh daftar hash, gabungkan dengan database yang ada, simpan ke disk.
fn do_update(inner: &Inner, auto: bool) -> Result<usize, String> {
    let url = inner.settings.lock().unwrap().signature_url.clone();
    if url.is_empty() {
        return Err("URL signature belum diisi di Settings".into());
    }
    let text = signatures::download(&url, 128 * 1024 * 1024)?;
    let mut merged = inner.db.read().unwrap().clone();
    let added = merged.load_text(&text);
    if added == 0 {
        return Err("Daftar tidak berisi hash SHA-256 yang valid".into());
    }
    std::fs::write(inner.data_dir.join("signatures.txt"), merged.to_text()).map_err(|e| e.to_string())?;
    let total = merged.len();
    *inner.db.write().unwrap() = merged;
    inner.with_settings(|s| s.last_update = now_secs());
    inner.with_state(|s| {
        let title = if auto { "Signature diperbarui (otomatis)" } else { "Signature diperbarui" };
        s.log(title, &format!("{} entri, +{} dibaca", total, added), "info");
    });
    Ok(total)
}

#[tauri::command]
async fn update_signatures(shared: TauriState<'_, Shared>) -> Result<usize, String> {
    let inner = shared.inner.clone();
    tauri::async_runtime::spawn_blocking(move || do_update(&inner, false))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
fn save_settings(shared: TauriState<Shared>, settings: Settings) -> Result<Settings, String> {
    let mut new = settings;
    new.sanitize();
    Ok(shared.inner.with_settings(|cur| {
        // waktu terakhir dikelola backend, bukan UI
        new.last_update = cur.last_update;
        new.last_scheduled_scan = cur.last_scheduled_scan;
        *cur = new;
        cur.clone()
    }))
}

// ───────────────────────── scheduler ─────────────────────────

/// Satu thread latar belakang: update signature berkala (termasuk saat aplikasi dibuka,
/// karena `last_update == 0` atau sudah lewat interval) dan scan terjadwal.
fn start_scheduler(app: AppHandle, inner: Arc<Inner>, cancel: Arc<AtomicBool>, scanning: Arc<AtomicBool>) {
    std::thread::spawn(move || {
        let mut retry_after: i64 = 0;
        std::thread::sleep(Duration::from_secs(5)); // beri waktu UI tampil dulu
        loop {
            let now = now_secs();
            let cfg = inner.settings.lock().unwrap().clone();

            if cfg.auto_update && now >= retry_after && is_due(cfg.last_update, now, cfg.update_every_hours) {
                match do_update(&inner, true) {
                    Ok(n) => {
                        let _ = app.emit("signatures-updated", n);
                    }
                    Err(e) => {
                        retry_after = now + 30 * 60; // coba lagi 30 menit kemudian
                        inner.with_state(|s| s.log("Update signature gagal", &e, "info"));
                        let _ = app.emit("signatures-updated", 0usize);
                    }
                }
            }

            if cfg.schedule_enabled && is_due(cfg.last_scheduled_scan, now, cfg.schedule_every_hours) {
                let (label, targets) = if cfg.schedule_kind == "full" {
                    ("Full scan terjadwal", full_targets(&app))
                } else {
                    ("Quick scan terjadwal", quick_targets(&app))
                };
                let started = !targets.is_empty()
                    && spawn_scan(app.clone(), inner.clone(), cancel.clone(), scanning.clone(), label.to_string(), targets);
                if started {
                    inner.with_settings(|s| s.last_scheduled_scan = now);
                }
            }

            std::thread::sleep(Duration::from_secs(30));
        }
    });
}

// ───────────────────────── entry point ─────────────────────────

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            let data_dir = app.path().app_data_dir()?;
            std::fs::create_dir_all(&data_dir)?;

            let quarantine = Quarantine::new(data_dir.join("quarantine"))?;
            let mut db = SignatureDb::with_builtin();
            let _ = db.load_file(&data_dir.join("signatures.txt"));
            let state = State::load(&data_dir.join("state.json"));
            let mut settings = Settings::load(&data_dir.join("settings.json"));
            if settings.last_scheduled_scan == 0 {
                // scan terjadwal pertama = satu interval setelah pemasangan, bukan langsung
                settings.last_scheduled_scan = now_secs();
                let _ = settings.save(&data_dir.join("settings.json"));
            }

            let inner = Arc::new(Inner {
                data_dir,
                db: RwLock::new(db),
                state: Mutex::new(state),
                quarantine: Mutex::new(quarantine),
                settings: Mutex::new(settings),
            });

            // Real-time aktif secara default.
            let watcher = start_watcher(app.handle().clone(), inner.clone(), watch_paths(app.handle())).ok();

            let cancel = Arc::new(AtomicBool::new(false));
            let scanning = Arc::new(AtomicBool::new(false));
            start_scheduler(app.handle().clone(), inner.clone(), cancel.clone(), scanning.clone());

            app.manage(Shared { inner, cancel, scanning, watcher: Mutex::new(watcher) });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_snapshot,
            start_scan,
            cancel_scan,
            set_realtime,
            quarantine_restore,
            quarantine_delete,
            check_file,
            update_signatures,
            save_settings
        ])
        .run(tauri::generate_context!())
        .expect("gagal menjalankan Guardian");
}
