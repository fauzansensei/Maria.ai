import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { open } from "@tauri-apps/plugin-dialog";

export type QItem = {
  id: string;
  name: string;
  category: string;
  severity: string;
  original_path: string;
  sha256: string;
  size: number;
  quarantined_at: number;
};
export type LogEntry = { ts: number; title: string; detail: string; status: string };
export type Settings = {
  auto_update: boolean;
  update_every_hours: number;
  signature_url: string;
  schedule_enabled: boolean;
  schedule_every_hours: number;
  schedule_kind: "quick" | "full";
  last_update: number;
  last_scheduled_scan: number;
};
export type Snapshot = {
  platform: string;
  device: string;
  realtime: boolean;
  scanning: boolean;
  signatureCount: number;
  quarantine: QItem[];
  totalScanned: number;
  totalRemoved: number;
  byDay: Record<string, number>;
  byCategory: Record<string, number>;
  log: LogEntry[];
  settings: Settings;
};
export type Progress = { phase: "counting" | "scanning"; total: number; scanned: number; threats: number; current: string };
export type ScanDone = { label: string; scanned: number; found: number; quarantined: number; cancelled: boolean };
export type RealtimeHit = { name: string; path: string; quarantined: boolean };
export type CheckResult = { sha256: string; verdict: "clean" | "threat"; name: string | null; reason: string | null };

export const api = {
  snapshot: () => invoke<Snapshot>("get_snapshot"),
  startScan: (kind: "quick" | "full" | "folder", path?: string) => invoke<void>("start_scan", { kind, path }),
  cancelScan: () => invoke<void>("cancel_scan"),
  setRealtime: (on: boolean) => invoke<boolean>("set_realtime", { on }),
  restore: (id: string) => invoke<string>("quarantine_restore", { id }),
  remove: (id: string) => invoke<void>("quarantine_delete", { id }),
  checkFile: (path: string) => invoke<CheckResult>("check_file", { path }),
  updateSignatures: () => invoke<number>("update_signatures"),
  saveSettings: (settings: Settings) => invoke<Settings>("save_settings", { settings }),
  pickFolder: async () => {
    const r = await open({ directory: true, multiple: false });
    return typeof r === "string" ? r : null;
  },
  pickFile: async () => {
    const r = await open({ directory: false, multiple: false });
    return typeof r === "string" ? r : null;
  },
};

export const on = <T,>(event: string, cb: (p: T) => void): Promise<UnlistenFn> =>
  listen<T>(event, (e) => cb(e.payload));
