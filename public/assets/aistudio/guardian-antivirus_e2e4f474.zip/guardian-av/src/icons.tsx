import type { ReactNode } from "react";

const S = (p: { children: ReactNode; size?: number }) => (
  <svg width={p.size ?? 18} height={p.size ?? 18} viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{p.children}</svg>
);
const SHIELD = "M12 3l8 3v6c0 4.5-3.3 8-8 9-4.7-1-8-4.5-8-9V6l8-3z";

export const ShieldOk = ({ size = 30 }) => <S size={size}><path d={SHIELD} /><path d="M8.5 12l2.5 2.5L16 9.5" /></S>;
export const ShieldBad = ({ size = 30 }) => <S size={size}><path d={SHIELD} /><path d="M12 8v5M12 16.5h.01" /></S>;
export const ShieldOff = ({ size = 30 }) => <S size={size}><path d={SHIELD} /><path d="M9 9l6 6M15 9l-6 6" /></S>;
export const Bolt = () => <S><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" /></S>;
export const Scan = () => <S><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></S>;
export const Folder = () => <S><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z" /></S>;
export const Box = () => <S><path d="M21 8l-9-5-9 5v8l9 5 9-5V8z" /><path d="M3 8l9 5 9-5M12 13v8" /></S>;
export const List = () => <S><path d="M4 6h16M4 12h16M4 18h10" /></S>;
export const Info = () => <S><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></S>;
export const Refresh = () => <S><path d="M21 12a9 9 0 11-3-6.7M21 4v5h-5" /></S>;
export const Gear = () => <S><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z" /></S>;
export const Sun = () => <S size={15}><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></S>;
export const Logo = () => <ShieldOk size={22} />;
