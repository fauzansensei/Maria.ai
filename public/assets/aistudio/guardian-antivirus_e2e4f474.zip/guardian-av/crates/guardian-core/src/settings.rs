use serde::{Deserialize, Serialize};
use std::fs;
use std::io;
use std::path::Path;

pub const DEFAULT_SIGNATURE_URL: &str = "https://bazaar.abuse.ch/export/txt/sha256/recent/";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
#[serde(default)]
pub struct Settings {
    pub auto_update: bool,
    pub update_every_hours: u32,
    pub signature_url: String,
    pub schedule_enabled: bool,
    pub schedule_every_hours: u32,
    /// "quick" atau "full"
    pub schedule_kind: String,
    /// unix detik; 0 = belum pernah
    pub last_update: i64,
    pub last_scheduled_scan: i64,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            auto_update: true,
            update_every_hours: 6,
            signature_url: DEFAULT_SIGNATURE_URL.to_string(),
            schedule_enabled: true,
            schedule_every_hours: 24,
            schedule_kind: "quick".to_string(),
            last_update: 0,
            last_scheduled_scan: 0,
        }
    }
}

impl Settings {
    /// Rapikan nilai di luar batas.
    pub fn sanitize(&mut self) {
        self.update_every_hours = self.update_every_hours.clamp(1, 168);
        self.schedule_every_hours = self.schedule_every_hours.clamp(1, 720);
        if self.schedule_kind != "quick" && self.schedule_kind != "full" {
            self.schedule_kind = "quick".into();
        }
        self.signature_url = self.signature_url.trim().to_string();
    }

    pub fn load(path: &Path) -> Self {
        let mut s: Settings = fs::read_to_string(path)
            .ok()
            .and_then(|t| serde_json::from_str(&t).ok())
            .unwrap_or_default();
        s.sanitize();
        s
    }

    pub fn save(&self, path: &Path) -> io::Result<()> {
        let json = serde_json::to_string_pretty(self).map_err(io::Error::other)?;
        fs::write(path, json)
    }
}

/// Apakah pekerjaan berkala sudah waktunya jalan? `last == 0` berarti belum pernah.
pub fn is_due(last: i64, now: i64, every_hours: u32) -> bool {
    last <= 0 || now - last >= every_hours as i64 * 3600
}
