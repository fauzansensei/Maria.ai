use std::collections::HashMap;
use std::io;
use std::path::Path;

/// SHA-256 dari file uji standar EICAR (aman, dipakai untuk menguji antivirus).
pub const EICAR_SHA256: &str = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f";

#[derive(Clone, Debug)]
pub struct SigInfo {
    pub name: String,
    pub category: String,
}

#[derive(Clone, Default)]
pub struct SignatureDb {
    map: HashMap<String, SigInfo>,
}

fn is_sha256(s: &str) -> bool {
    s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit())
}

impl SignatureDb {
    pub fn with_builtin() -> Self {
        let mut db = Self::default();
        db.insert(EICAR_SHA256, "EICAR-Test-File", "Test");
        db
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }

    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    pub fn insert(&mut self, sha256: &str, name: &str, category: &str) {
        self.map.insert(
            sha256.to_ascii_lowercase(),
            SigInfo { name: name.to_string(), category: category.to_string() },
        );
    }

    pub fn lookup(&self, sha256: &str) -> Option<&SigInfo> {
        self.map.get(sha256)
    }

    /// Format yang diterima per baris (komentar diawali # atau //):
    ///   <sha256>
    ///   <sha256>,<Nama>,<Kategori>
    /// Baris CSV lain (misalnya ekspor MalwareBazaar) juga diterima: token 64-hex pertama dipakai.
    pub fn load_text(&mut self, text: &str) -> usize {
        let mut added = 0;
        for line in text.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') || line.starts_with("//") {
                continue;
            }
            let tokens: Vec<&str> = line
                .split(|c| c == ',' || c == ';' || c == '\t' || c == ' ')
                .map(|t| t.trim().trim_matches('"'))
                .filter(|t| !t.is_empty())
                .collect();
            let Some(i) = tokens.iter().position(|t| is_sha256(t)) else { continue };
            let name = tokens.get(i + 1).copied().unwrap_or("Malware.Signature");
            let category = tokens.get(i + 2).copied().unwrap_or("Malware");
            if self.map.len() >= 5_000_000 {
                break;
            }
            self.insert(tokens[i], name, category);
            added += 1;
        }
        added
    }

    /// Serialisasi seluruh database ke format yang bisa dibaca `load_text` (untuk disimpan ke disk).
    pub fn to_text(&self) -> String {
        let clean = |t: &str| t.replace([',', ' ', '\n', '\r', '\t'], "_");
        let mut out = String::with_capacity(self.map.len() * 90);
        for (hash, info) in &self.map {
            out.push_str(hash);
            out.push(',');
            out.push_str(&clean(&info.name));
            out.push(',');
            out.push_str(&clean(&info.category));
            out.push('\n');
        }
        out
    }

    pub fn load_file(&mut self, path: &Path) -> io::Result<usize> {
        let text = std::fs::read_to_string(path)?;
        Ok(self.load_text(&text))
    }
}

/// Unduh daftar signature (teks). Dibatasi `max_bytes` agar tidak memenuhi memori.
#[cfg(feature = "net")]
pub fn download(url: &str, max_bytes: u64) -> Result<String, String> {
    use std::io::Read;
    if !url.starts_with("https://") {
        return Err("URL harus diawali https://".into());
    }
    let resp = ureq::get(url)
        .timeout(std::time::Duration::from_secs(60))
        .call()
        .map_err(|e| e.to_string())?;
    let mut buf = String::new();
    resp.into_reader()
        .take(max_bytes)
        .read_to_string(&mut buf)
        .map_err(|e| e.to_string())?;
    Ok(buf)
}
